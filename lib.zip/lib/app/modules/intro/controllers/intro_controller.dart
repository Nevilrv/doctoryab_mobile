import 'package:get/get.dart';

class IntroController extends GetxController {
  bool splahScreenMode = true;
  @override
  void onInit() {
    // if (!Get.arguments is bool) {
    //   splahScreenMode = null;
    // }
    // {
    //   splahScreenMode = Get.arguments;
    // }
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
}
