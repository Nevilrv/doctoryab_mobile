import 'package:get/get.dart';

import '../controllers/tab_home_others_controller.dart';

class TabHomeOthersBinding extends Bindings {
  @override
  void dependencies() {
    // Get.lazyPut<TabHomeOthersController>(
    //   () => TabHomeOthersController(),
    // );
  }
}
