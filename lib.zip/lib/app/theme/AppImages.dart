class AppImages {
  static const home = "assets/svg/Vector.svg";
  static const message = "assets/svg/Chat_Dots.svg";
  static const heart = "assets/svg/heart.svg";
  static const enquiry = "assets/svg/News.svg";
  static const profile = "assets/svg/profile.svg";
  static const menu = "assets/svg/menu.svg";
}
